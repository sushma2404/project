import { Directive, ElementRef } from '@angular/core';

@Directive({
  selector: '[appChangeText]'
})
export class ChangeTextDirective {

  constructor(private ele: ElementRef) {
    ele.nativeElement.innerText= "Hello text is changed";
   }

}
