import { Component, Input } from '@angular/core';

@Component({
  selector: 's1',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
     ParentValue: string= 'I am parent ';

  title = 'capgemini';
  id:number = 101;
name:string = 'sushma';
invalid: boolean = true;
value:any= 20000;
image= 'assets/img.png';
city: string= 'kakinada';
 sayHello()
{
  alert('hello sushma');
}
getData(value)
{
     alert(value);
}
}

