import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
   eid: number;
   ename: string;
  constructor() { }

  ngOnInit() {
  }
  getFormData(value)
  {
    alert(value.eid+" "+value.ename);
  }
}
