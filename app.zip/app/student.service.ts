import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StudentService {

  constructor() { }
  student = {"sid":"101","sname":"sushma","course":"angular"};
  getStudent(){
    console.log("Displayed in consoled");
  }




}
