import { Component, OnInit, Input, Output , EventEmitter} from '@angular/core';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
 name:string = 'sushma';
 @Input()
  acceptData: string;
 @Output()
 obj: EventEmitter<string> = new EventEmitter<String>();
  constructor() { }

  ngOnInit() {
  }
  childData:string='I am child';
  sendData()
  {
    this.obj.emit(this.childData);
  }
}
