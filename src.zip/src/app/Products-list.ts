export interface ProductList
{

id: number;
name: string;
price: number;
category: string;


}
