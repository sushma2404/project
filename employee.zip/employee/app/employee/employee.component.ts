import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import {Employee} from '../Employee';
import { AstMemoryEfficientTransformer } from '../../../node_modules/@angular/compiler';
@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  constructor(private service: EmployeeService) { }
   empList: Employee[];
  ngOnInit() {
    this.getAllEmployee();
  }
   getAllEmployee()
   {
     this.service.getAllEmployee().subscribe(Data => this.empList = Data);
   }
   deleteEmployee(i)
   {
     this.empList.splice(i,1);
   }
   delete(myform)
   {
    let count=0;
     for(let i=0 ; i<this.empList.length; i++)
     {
       if(this.empList[i].eid == myform.value.eid)
       {
        this.empList.splice(i,1);
         count=1;
       }
     }
     if(count==0){
      alert("Invalid eid");
    }
   }
   addEmployee(addform)
   {

         this.empList.push(addform.value);
   }
   updateEmployee(updateform)
   {
     let count=0;
     for(let i=0;i<this.empList.length; i++)
     {
       if(this.empList[i].eid==updateform.value.eid)
       {
         this.empList[i]=updateform.value;
         count=1;
       }
     }
    if(count==0)
    {
      alert('updation failed');
    }
   }

}
